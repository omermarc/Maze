package View;

public interface IView {
    void displayMaze(int[][] maze);
}
